using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace FinalProject
{
    static class CodeProgram
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            
            EntranceForm aDlg = new EntranceForm();

            int i = 1;
            do
            {
                if (i > 1)
                    MessageBox.Show("Your password is incorrect!");

                aDlg.ShowDialog();
                i++;
            }
            while (i <= 3 && !aDlg.IsValidUser);
            {

            }

            if (i >= 3)
                MessageBox.Show("You do not have permission!");
            else
                Application.Run(new GUI_RUMBLE());
            
        }
    }
}