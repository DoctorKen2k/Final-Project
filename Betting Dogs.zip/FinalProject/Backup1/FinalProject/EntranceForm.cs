using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace FinalProject
{
    public partial class EntranceForm : Form
    {
        private bool bValidUser;
        private bool bCancel;
        public EntranceForm()
        {
            InitializeComponent();
        }

        public bool IsValidUser
        {
            get
            {
                return bValidUser;
            }
            set
            {
                bValidUser = value;
            }
        }

        public bool IsCancel
        {
            get
            {
                return bCancel;
            }
            set
            {
                bCancel = value;
            }
        }

        private void butLeave_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void butEnter_Click(object sender, EventArgs e)
        {
            if (EnterBox.Text == "tsu")
                bValidUser = true;
                this.Close();
        }

        private void EntranceForm_Load(object sender, EventArgs e)
        {

        }

        
    }
}