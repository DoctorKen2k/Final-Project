using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace FinalProject
{
    public partial class GUI_RUMBLE : Form
    {
        private int a = 205, b = 205;
        private int c = 560, d = 560;
        private int GlobalSmackdown;
        
        private Graphics k, kk;
        private Random r = new Random();
        Icon BIcon, MIcon, DeadIcon;

        private int First = 0;
        private bool FirstOk = true;
        private int Second = 0;
        private bool SecondOk = true;

        public GUI_RUMBLE()
        {
            InitializeComponent();
            BIcon = new Icon("Bulldog.ico");
            MIcon = new Icon("Md Dog.ico");
            DeadIcon = new Icon("Bulldog 2.ico");
            kk = this.CreateGraphics();
        }

        private void GUI_RUMBLE_Paint(object sender, PaintEventArgs e)
        {
            k = e.Graphics;

            k.DrawLine(Pens.Green, 200, 200, 200, 600);
            k.DrawLine(Pens.Red, 190, 190, 190, 610);

            k.DrawLine(Pens.Green, 200, 200, 600, 200);
            k.DrawLine(Pens.Red, 190, 190, 610, 190);

            k.DrawLine(Pens.Green, 600, 200, 600, 600);
            k.DrawLine(Pens.Red, 610, 190, 610, 610);


            k.DrawLine(Pens.Green, 200, 600, 600, 600);
            k.DrawLine(Pens.Red, 190, 610, 610, 610);
            
            k.DrawIcon(BIcon, a, b);
            k.DrawIcon(MIcon, c, d);

            if (a == c && b == d)
            {
                if (GlobalSmackdown == 0)
                {
                    kk.DrawIcon(DeadIcon, 200, 200);
                    kk.DrawIcon(BIcon, a, b);
                }
                else
                    if (GlobalSmackdown == 1)
                    {
                        kk.DrawIcon(DeadIcon, 200, 200);
                        kk.DrawIcon(MIcon, c, d);   
                    }
            }
        }

        private void butExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Clock_Tick(object sender, EventArgs e)
        {
            a = r.Next(390, 410);
            b = r.Next(390, 410);
            c = r.Next(390, 410);
            d = r.Next(390, 410);
            GlobalSmackdown = r.Next(0, 2);
            this.Invalidate();

            if (a == c && b == d)
            {
                if (GlobalSmackdown == 0)
                {
                    
                    Clock.Enabled = false;
                    MessageBox.Show("If you did not pick the Bulldog, you owe us your total bet!", "Bulldog Wins");
                    
                }
                else
                    if (GlobalSmackdown == 1)
                    {
                        
                        Clock.Enabled = false;
                        MessageBox.Show("If you did not pick the Mad Dog, you owe us your total bet!", "Mad Dog Wins");
                        
                    }
            }
        }

        private void Bulldog_Click(object sender, EventArgs e)
        {
            if (Bulldog.Checked)
                BetBox.Visible = true;
            else
                BetBox.Visible = false;
            if (Bulldog.Checked)
                PlaceLabel.Visible = true;
            else
                PlaceLabel.Visible = false;
        }

        private void MadDog_Click(object sender, EventArgs e)
        {
            if (MadDog.Checked)
                BetBox.Visible = true;
            else
                BetBox.Visible = false;
            if (MadDog.Checked)
                PlaceLabel.Visible = true;
            else
                PlaceLabel.Visible = false;
        }

        private void BetBox_TextChanged(object sender, EventArgs e)
        {
            try
            {
                First = Convert.ToInt32(BetBox.Text);
                FirstOk = true;
                TotalBox.Text = "";
                if (SecondOk)
                {
                    butCalc.Enabled = true;
                }
            }
            catch (Exception except)
            {
                TotalBox.Text = "Error: Invalid First Number";
                butCalc.Enabled = false;
                FirstOk = false;
            }

            int t;
            if (BetBox.Text == "$")
            {
                MultiplyBox.Visible = false;
            }
            else
            {
                t = Int32.Parse(BetBox.Text);
                if (t >= 0)
                    MultiplyBox.Visible = true;
                else
                    MultiplyBox.Visible = false;

                if (t >= 0)
                    MultiplyLabel.Visible = true;
                else
                    MultiplyLabel.Visible = false;
            }
        }

        private void MultiplyBox_TextChanged(object sender, EventArgs e)
        {
            try
            {
                Second = Convert.ToInt32(MultiplyBox.Text);
                SecondOk = true;
                TotalBox.Text = "";
                if (FirstOk)
                {
                    butCalc.Enabled = true;
                }
            }
            catch (Exception except)
            {
                TotalBox.Text = "Error: Invalid Second Number";
                butCalc.Enabled = false;
                SecondOk = false;
            }

            int s;
            if (MultiplyBox.Text == "")
            {
                butCalc.Visible = false;
            }
            else
            {
                s = Int32.Parse(BetBox.Text);
                if (s >= 0)
                    butCalc.Visible = true;
                else
                    butCalc.Visible = false;

                if (s >= 0)
                    SureLabel.Visible = true;
                else
                    SureLabel.Visible = false;
            }
        }

        private void butCalc_Click(object sender, EventArgs e)
        {
            int sum = First * Second;
            TotalBox.Text = "$" + sum;
            BellButton.Visible = true;
            TimeOutButton.Visible = true;
            TotalBox.Visible = true;
            TotalLabel.Visible = true;
        }

        private void BellButton_Click(object sender, EventArgs e)
        {
            Clock.Enabled = true;
        }

        private void TimeOutButton_Click(object sender, EventArgs e)
        {
            Clock.Enabled = false;
            
        }

        

        private void helpform_Click(object sender, EventArgs e)
        {
            Help helpdialog = new Help();
            helpdialog.ShowDialog();
        }

        private void newBut_Click(object sender, EventArgs e)
        {
            BetBox.ResetText();
            MultiplyBox.ResetText();
            TotalBox.ResetText();
            EntranceForm entranceDialog = new EntranceForm();
            entranceDialog.ShowDialog();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void GUI_RUMBLE_Load(object sender, EventArgs e)
        {

        }

        private void Bulldog_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void MadDog_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void TotalBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void fileToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void toolStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

       
        
    }

}
