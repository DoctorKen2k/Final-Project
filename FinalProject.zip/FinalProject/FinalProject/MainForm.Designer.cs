namespace FinalProject
{
    partial class GUI_RUMBLE
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GUI_RUMBLE));
            this.Clock = new System.Windows.Forms.Timer(this.components);
            this.BellButton = new System.Windows.Forms.Button();
            this.TimeOutButton = new System.Windows.Forms.Button();
            this.CYF_GroupBox = new System.Windows.Forms.GroupBox();
            this.MadDog = new System.Windows.Forms.RadioButton();
            this.Bulldog = new System.Windows.Forms.RadioButton();
            this.PlaceLabel = new System.Windows.Forms.Label();
            this.MultiplyLabel = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.BetBox = new System.Windows.Forms.TextBox();
            this.MultiplyBox = new System.Windows.Forms.TextBox();
            this.butCalc = new System.Windows.Forms.Button();
            this.TotalLabel = new System.Windows.Forms.Label();
            this.TotalBox = new System.Windows.Forms.TextBox();
            this.butExit = new System.Windows.Forms.Button();
            this.SureLabel = new System.Windows.Forms.Label();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.newBut = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpform = new System.Windows.Forms.ToolStripLabel();
            this.CYF_GroupBox.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // Clock
            // 
            this.Clock.Interval = 10;
            this.Clock.Tick += new System.EventHandler(this.Clock_Tick);
            // 
            // BellButton
            // 
            this.BellButton.ForeColor = System.Drawing.Color.LightBlue;
            this.BellButton.Image = ((System.Drawing.Image)(resources.GetObject("BellButton.Image")));
            this.BellButton.Location = new System.Drawing.Point(12, 227);
            this.BellButton.Name = "BellButton";
            this.BellButton.Size = new System.Drawing.Size(137, 176);
            this.BellButton.TabIndex = 0;
            this.BellButton.Text = "Ring The Bell!";
            this.BellButton.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.BellButton.UseVisualStyleBackColor = false;
            this.BellButton.Visible = false;
            this.BellButton.Click += new System.EventHandler(this.BellButton_Click);
            // 
            // TimeOutButton
            // 
            this.TimeOutButton.ForeColor = System.Drawing.Color.LightBlue;
            this.TimeOutButton.Image = ((System.Drawing.Image)(resources.GetObject("TimeOutButton.Image")));
            this.TimeOutButton.Location = new System.Drawing.Point(12, 409);
            this.TimeOutButton.Name = "TimeOutButton";
            this.TimeOutButton.Size = new System.Drawing.Size(141, 132);
            this.TimeOutButton.TabIndex = 1;
            this.TimeOutButton.Text = "Time Out";
            this.TimeOutButton.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.TimeOutButton.UseVisualStyleBackColor = false;
            this.TimeOutButton.Visible = false;
            this.TimeOutButton.Click += new System.EventHandler(this.TimeOutButton_Click);
            // 
            // CYF_GroupBox
            // 
            this.CYF_GroupBox.Controls.Add(this.MadDog);
            this.CYF_GroupBox.Controls.Add(this.Bulldog);
            this.CYF_GroupBox.ForeColor = System.Drawing.Color.LightBlue;
            this.CYF_GroupBox.Location = new System.Drawing.Point(12, 113);
            this.CYF_GroupBox.Name = "CYF_GroupBox";
            this.CYF_GroupBox.Size = new System.Drawing.Size(141, 69);
            this.CYF_GroupBox.TabIndex = 3;
            this.CYF_GroupBox.TabStop = false;
            this.CYF_GroupBox.Text = "\"Choose Your Fighter!\"";
            // 
            // MadDog
            // 
            this.MadDog.AutoSize = true;
            this.MadDog.Location = new System.Drawing.Point(7, 42);
            this.MadDog.Name = "MadDog";
            this.MadDog.Size = new System.Drawing.Size(69, 17);
            this.MadDog.TabIndex = 1;
            this.MadDog.TabStop = true;
            this.MadDog.Text = "Mad Dog";
            this.MadDog.UseVisualStyleBackColor = true;
            this.MadDog.Click += new System.EventHandler(this.MadDog_Click);
            this.MadDog.CheckedChanged += new System.EventHandler(this.MadDog_CheckedChanged);
            // 
            // Bulldog
            // 
            this.Bulldog.AutoSize = true;
            this.Bulldog.Location = new System.Drawing.Point(6, 19);
            this.Bulldog.Name = "Bulldog";
            this.Bulldog.Size = new System.Drawing.Size(60, 17);
            this.Bulldog.TabIndex = 0;
            this.Bulldog.TabStop = true;
            this.Bulldog.Text = "Bulldog";
            this.Bulldog.UseVisualStyleBackColor = true;
            this.Bulldog.Click += new System.EventHandler(this.Bulldog_Click);
            this.Bulldog.CheckedChanged += new System.EventHandler(this.Bulldog_CheckedChanged);
            // 
            // PlaceLabel
            // 
            this.PlaceLabel.AutoSize = true;
            this.PlaceLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PlaceLabel.ForeColor = System.Drawing.Color.LightBlue;
            this.PlaceLabel.Location = new System.Drawing.Point(180, 103);
            this.PlaceLabel.Name = "PlaceLabel";
            this.PlaceLabel.Size = new System.Drawing.Size(79, 15);
            this.PlaceLabel.TabIndex = 9;
            this.PlaceLabel.Text = "\"Place a bet!\"";
            this.PlaceLabel.Visible = false;
            // 
            // MultiplyLabel
            // 
            this.MultiplyLabel.AutoSize = true;
            this.MultiplyLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MultiplyLabel.ForeColor = System.Drawing.Color.LightBlue;
            this.MultiplyLabel.Location = new System.Drawing.Point(273, 103);
            this.MultiplyLabel.Name = "MultiplyLabel";
            this.MultiplyLabel.Size = new System.Drawing.Size(69, 15);
            this.MultiplyLabel.TabIndex = 10;
            this.MultiplyLabel.Text = "\"Multiply It!\"";
            this.MultiplyLabel.Visible = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(673, 293);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(0, 13);
            this.label3.TabIndex = 11;
            // 
            // BetBox
            // 
            this.BetBox.Location = new System.Drawing.Point(183, 141);
            this.BetBox.Multiline = true;
            this.BetBox.Name = "BetBox";
            this.BetBox.Size = new System.Drawing.Size(71, 41);
            this.BetBox.TabIndex = 12;
            this.BetBox.Visible = false;
            this.BetBox.TextChanged += new System.EventHandler(this.BetBox_TextChanged);
            // 
            // MultiplyBox
            // 
            this.MultiplyBox.Location = new System.Drawing.Point(276, 141);
            this.MultiplyBox.Multiline = true;
            this.MultiplyBox.Name = "MultiplyBox";
            this.MultiplyBox.Size = new System.Drawing.Size(61, 41);
            this.MultiplyBox.TabIndex = 13;
            this.MultiplyBox.Visible = false;
            this.MultiplyBox.TextChanged += new System.EventHandler(this.MultiplyBox_TextChanged);
            // 
            // butCalc
            // 
            this.butCalc.Image = ((System.Drawing.Image)(resources.GetObject("butCalc.Image")));
            this.butCalc.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.butCalc.Location = new System.Drawing.Point(399, 121);
            this.butCalc.Name = "butCalc";
            this.butCalc.Size = new System.Drawing.Size(58, 65);
            this.butCalc.TabIndex = 14;
            this.butCalc.UseVisualStyleBackColor = false;
            this.butCalc.Visible = false;
            this.butCalc.Click += new System.EventHandler(this.butCalc_Click);
            // 
            // TotalLabel
            // 
            this.TotalLabel.AutoSize = true;
            this.TotalLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TotalLabel.ForeColor = System.Drawing.Color.LightBlue;
            this.TotalLabel.Location = new System.Drawing.Point(541, 103);
            this.TotalLabel.Name = "TotalLabel";
            this.TotalLabel.Size = new System.Drawing.Size(89, 15);
            this.TotalLabel.TabIndex = 15;
            this.TotalLabel.Text = "\"Your total bet!\"";
            this.TotalLabel.Visible = false;
            // 
            // TotalBox
            // 
            this.TotalBox.Location = new System.Drawing.Point(544, 121);
            this.TotalBox.Multiline = true;
            this.TotalBox.Name = "TotalBox";
            this.TotalBox.Size = new System.Drawing.Size(80, 65);
            this.TotalBox.TabIndex = 17;
            this.TotalBox.Visible = false;
            this.TotalBox.TextChanged += new System.EventHandler(this.TotalBox_TextChanged);
            // 
            // butExit
            // 
            this.butExit.Image = ((System.Drawing.Image)(resources.GetObject("butExit.Image")));
            this.butExit.Location = new System.Drawing.Point(12, 547);
            this.butExit.Name = "butExit";
            this.butExit.Size = new System.Drawing.Size(64, 75);
            this.butExit.TabIndex = 18;
            this.butExit.UseVisualStyleBackColor = false;
            this.butExit.Click += new System.EventHandler(this.butExit_Click);
            // 
            // SureLabel
            // 
            this.SureLabel.AutoSize = true;
            this.SureLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SureLabel.ForeColor = System.Drawing.Color.LightBlue;
            this.SureLabel.Location = new System.Drawing.Point(360, 103);
            this.SureLabel.Name = "SureLabel";
            this.SureLabel.Size = new System.Drawing.Size(171, 15);
            this.SureLabel.TabIndex = 19;
            this.SureLabel.Text = "\"Are You Sure?  Click \'?\' If So!\"";
            this.SureLabel.Visible = false;
            // 
            // toolStrip1
            // 
            this.toolStrip1.BackColor = System.Drawing.Color.SteelBlue;
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.helpform});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(648, 25);
            this.toolStrip1.TabIndex = 22;
            this.toolStrip1.Text = "toolStrip1";
            this.toolStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.toolStrip1_ItemClicked);
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newBut,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.O)));
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(35, 25);
            this.fileToolStripMenuItem.Text = "File";
            this.fileToolStripMenuItem.Click += new System.EventHandler(this.fileToolStripMenuItem_Click);
            // 
            // newBut
            // 
            this.newBut.Name = "newBut";
            this.newBut.Size = new System.Drawing.Size(152, 22);
            this.newBut.Text = "New";
            this.newBut.Click += new System.EventHandler(this.newBut_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // helpform
            // 
            this.helpform.Name = "helpform";
            this.helpform.Size = new System.Drawing.Size(28, 22);
            this.helpform.Text = "Help";
            this.helpform.Click += new System.EventHandler(this.helpform_Click);
            // 
            // GUI_RUMBLE
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Maroon;
            this.ClientSize = new System.Drawing.Size(648, 689);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.SureLabel);
            this.Controls.Add(this.butExit);
            this.Controls.Add(this.TotalBox);
            this.Controls.Add(this.TotalLabel);
            this.Controls.Add(this.butCalc);
            this.Controls.Add(this.MultiplyBox);
            this.Controls.Add(this.BetBox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.MultiplyLabel);
            this.Controls.Add(this.PlaceLabel);
            this.Controls.Add(this.CYF_GroupBox);
            this.Controls.Add(this.TimeOutButton);
            this.Controls.Add(this.BellButton);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "GUI_RUMBLE";
            this.Load += new System.EventHandler(this.GUI_RUMBLE_Load);
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.GUI_RUMBLE_Paint);
            this.CYF_GroupBox.ResumeLayout(false);
            this.CYF_GroupBox.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Timer Clock;
        private System.Windows.Forms.Button BellButton;
        private System.Windows.Forms.Button TimeOutButton;
        private System.Windows.Forms.GroupBox CYF_GroupBox;
        private System.Windows.Forms.RadioButton MadDog;
        private System.Windows.Forms.RadioButton Bulldog;
        private System.Windows.Forms.Label PlaceLabel;
        private System.Windows.Forms.Label MultiplyLabel;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox BetBox;
        private System.Windows.Forms.TextBox MultiplyBox;
        private System.Windows.Forms.Button butCalc;
        private System.Windows.Forms.Label TotalLabel;
        private System.Windows.Forms.TextBox TotalBox;
        private System.Windows.Forms.Button butExit;
        private System.Windows.Forms.Label SureLabel;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripLabel helpform;
        private System.Windows.Forms.ToolStripMenuItem newBut;

    }
}

